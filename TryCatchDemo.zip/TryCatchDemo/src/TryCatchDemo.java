public class TryCatchDemo {
    public static void main(String[] args) {
        try {
            int[] numbers = { 1, 2, 3 };
            int result = divide(10, 2); // This method will not throw an exception
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("An ArithmeticException occurred: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An Exception occurred: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }

        System.out.println("Program continues...");
    }

    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }
}
