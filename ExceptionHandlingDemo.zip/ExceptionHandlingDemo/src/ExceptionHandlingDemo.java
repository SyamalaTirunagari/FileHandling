class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        try {
            throwCustomExceptionMethod();
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }

        System.out.println("Program continues...");
    }

    public static void throwCustomExceptionMethod() throws CustomException {
        try {
            int result = divide(10, 0); // This method will throw an ArithmeticException
        } catch (ArithmeticException e) {
            throw new CustomException("CustomException: Division by zero is not allowed.");
        }
    }

    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }
}

