class Car {
    private String brand;
    private String model;
    private int year;
    private boolean isRunning;

    // Constructor
    public Car(String brand, String model, int year) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.isRunning = false;
    }

    // Encapsulation
    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public void start() {
        isRunning = true;
        System.out.println("The car is now running.");
    }

    public void stop() {
        isRunning = false;
        System.out.println("The car has been stopped.");
    }

    // Polymorphism
    @Override
    public String toString() {
        return "Car Info: " + brand + " " + model + " (" + year + ")";
    }
}

public class ObjectOrientedDemo {
    public static void main(String[] args) {
        Car myCar = new Car("Toyota", "Camry", 2020); 

        // Encapsulation
        System.out.println("Car Brand: " + myCar.getBrand());
        System.out.println("Car Model: " + myCar.getModel());
        System.out.println("Car Year: " + myCar.getYear());

        // Polymorphism
        System.out.println(myCar); 

        // Abstraction
        myCar.start();
        myCar.stop();
    }
}
