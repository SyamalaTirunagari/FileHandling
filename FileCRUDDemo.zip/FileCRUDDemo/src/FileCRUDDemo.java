import java.io.*;

public class FileCRUDDemo {
    public static void main(String[] args) {
        String fileName = "file.txt";

        // Create
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write("This is a sample text.");
            fileWriter.close();
            System.out.println("File created successfully.");
        } catch (IOException e) {
            System.out.println("Error in file creation: " + e.getMessage());
        }

        // Read
        try {
            FileReader fileReader = new FileReader(fileName);
            char[] buffer = new char[1024];
            int bytesRead;
            StringBuffer stringBuffer = new StringBuffer();
            while ((bytesRead = fileReader.read(buffer)) != -1) {
                stringBuffer.append(buffer, 0, bytesRead);
            }
            System.out.println("File content: " + stringBuffer.toString());
            fileReader.close();
        } catch (IOException e) {
            System.out.println("Error in file reading: " + e.getMessage());
        }

        // Update
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write("This is an updated sample text.");
            fileWriter.close();
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.out.println("Error in file update: " + e.getMessage());
        }

        // Delete
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Error in file deletion.");
        }
    }
}